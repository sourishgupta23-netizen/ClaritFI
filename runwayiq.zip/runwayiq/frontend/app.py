# ============================================
# RunwayIQ — app.py
# Python Tkinter desktop frontend
# Run: python app.py
# Requires backend running on localhost:3000
# ============================================

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import requests
import threading
import json

API = "http://localhost:3000/api"

# ──────────────────────────────────────────────
# Colour palette
# ──────────────────────────────────────────────
BG       = "#0a0a0f"
PANEL    = "#12121a"
BORDER   = "#1e1e2a"
EMBER    = "#e84a1a"
GOLD     = "#c9a84c"
TEXT     = "#f5f2eb"
MUTED    = "#8a8680"
GREEN    = "#4caf78"
BTN_FG   = "#ffffff"

FONT_H1  = ("Helvetica", 22, "bold")
FONT_H2  = ("Helvetica", 15, "bold")
FONT_H3  = ("Helvetica", 11, "bold")
FONT_B   = ("Helvetica", 10)
FONT_SM  = ("Helvetica", 9)
FONT_MO  = ("Courier", 9)


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────
def fmt_inr(n):
    """Format number as ₹ with Indian comma grouping."""
    try:
        n = int(n)
        s = str(n)
        if len(s) <= 3:
            return f"₹{s}"
        last3 = s[-3:]
        rest  = s[:-3]
        parts = []
        while len(rest) > 2:
            parts.append(rest[-2:])
            rest = rest[:-2]
        if rest:
            parts.append(rest)
        return f"₹{','.join(reversed(parts))},{last3}"
    except Exception:
        return f"₹{n}"


def post(endpoint, payload):
    """POST to backend, return JSON or raise."""
    resp = requests.post(f"{API}/{endpoint}", json=payload, timeout=10)
    resp.raise_for_status()
    return resp.json()


def upload_file(path):
    """Upload CTC file, return JSON."""
    with open(path, "rb") as f:
        resp = requests.post(
            f"{API}/upload/ctc",
            files={"file": f},
            timeout=15,
        )
    resp.raise_for_status()
    return resp.json()


# ──────────────────────────────────────────────
# Reusable widgets
# ──────────────────────────────────────────────
def labeled_entry(parent, label, default="", width=18):
    frame = tk.Frame(parent, bg=PANEL)
    frame.pack(fill="x", pady=4)
    tk.Label(frame, text=label, bg=PANEL, fg=MUTED,
             font=FONT_SM, anchor="w", width=26).pack(side="left")
    var = tk.StringVar(value=default)
    ent = tk.Entry(frame, textvariable=var, width=width,
                   bg=BORDER, fg=TEXT, insertbackground=TEXT,
                   relief="flat", font=FONT_B, bd=4)
    ent.pack(side="left")
    return var


def section_label(parent, text):
    tk.Label(parent, text=text, bg=BG, fg=GOLD,
             font=FONT_H2, anchor="w").pack(fill="x", pady=(18, 6))
    tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", pady=(0, 10))


def card(parent, **kwargs):
    f = tk.Frame(parent, bg=PANEL, bd=0, relief="flat", **kwargs)
    f.pack(fill="x", pady=4, padx=0)
    return f


def btn(parent, text, command, color=EMBER):
    b = tk.Button(parent, text=text, command=command,
                  bg=color, fg=BTN_FG, activebackground=GOLD,
                  activeforeground=BTN_FG, relief="flat",
                  font=FONT_H3, padx=16, pady=8, cursor="hand2", bd=0)
    b.pack(pady=8)
    return b


def result_row(parent, label, value, value_color=TEXT):
    f = tk.Frame(parent, bg=PANEL)
    f.pack(fill="x", pady=2)
    tk.Label(f, text=label, bg=PANEL, fg=MUTED, font=FONT_SM,
             anchor="w", width=30).pack(side="left")
    tk.Label(f, text=value, bg=PANEL, fg=value_color,
             font=FONT_B, anchor="w").pack(side="left")


# ──────────────────────────────────────────────
# Main Application
# ──────────────────────────────────────────────
class RunwayIQ(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("RunwayIQ — From Payslip to Financial Freedom")
        self.geometry("920x700")
        self.configure(bg=BG)
        self.resizable(True, True)

        self._build_header()
        self._build_tabs()

    # ── Header ──────────────────────────────
    def _build_header(self):
        h = tk.Frame(self, bg=PANEL, pady=14)
        h.pack(fill="x")
        tk.Label(h, text="  RunwayIQ", bg=PANEL, fg=TEXT,
                 font=("Helvetica", 18, "bold")).pack(side="left")
        tk.Label(h, text="From Payslip to Financial Freedom",
                 bg=PANEL, fg=MUTED, font=FONT_SM).pack(side="left", padx=12)
        # Health indicator
        self.health_lbl = tk.Label(h, text="● backend", bg=PANEL,
                                   fg=MUTED, font=FONT_SM)
        self.health_lbl.pack(side="right", padx=12)
        threading.Thread(target=self._check_health, daemon=True).start()

    def _check_health(self):
        try:
            r = requests.get(f"{API}/health", timeout=3)
            if r.status_code == 200:
                self.health_lbl.config(text="● backend online", fg=GREEN)
            else:
                self.health_lbl.config(text="● backend error", fg=EMBER)
        except Exception:
            self.health_lbl.config(text="● backend offline", fg=EMBER)

    # ── Tabs ────────────────────────────────
    def _build_tabs(self):
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook",        background=BG,    borderwidth=0)
        style.configure("TNotebook.Tab",    background=PANEL, foreground=MUTED,
                        padding=[16, 8],   font=FONT_B)
        style.map("TNotebook.Tab",
                  background=[("selected", BG)],
                  foreground=[("selected", GOLD)])

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=0, pady=0)

        self.tab_upload   = self._scrollable(nb)
        self.tab_fire     = self._scrollable(nb)
        self.tab_business = self._scrollable(nb)

        nb.add(self.tab_upload,   text="  📄  Upload CTC  ")
        nb.add(self.tab_fire,     text="  🔥  FIRE Plan  ")
        nb.add(self.tab_business, text="  🏢  Business  ")

        self._build_upload_tab(self.tab_upload)
        self._build_fire_tab(self.tab_fire)
        self._build_business_tab(self.tab_business)

    def _scrollable(self, parent):
        """Returns a scrollable frame to use as a tab."""
        outer = tk.Frame(parent, bg=BG)
        canvas = tk.Canvas(outer, bg=BG, bd=0, highlightthickness=0)
        sb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG, padx=28, pady=20)

        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)

        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # Mouse wheel
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))
        return inner

    # ── Upload Tab ──────────────────────────
    def _build_upload_tab(self, p):
        section_label(p, "Upload Your CTC / Salary Slip")

        info = card(p, pady=10, padx=14)
        tk.Label(info, text="Supported formats: PDF, JPG, PNG  •  Max 10 MB",
                 bg=PANEL, fg=MUTED, font=FONT_SM).pack(anchor="w")
        tk.Label(info,
                 text="Your file is processed locally and deleted immediately after extraction.",
                 bg=PANEL, fg=MUTED, font=FONT_SM).pack(anchor="w", pady=(4, 0))

        self.file_lbl = tk.Label(p, text="No file selected",
                                 bg=BG, fg=MUTED, font=FONT_SM)
        self.file_lbl.pack(anchor="w", pady=(10, 2))

        btn_frame = tk.Frame(p, bg=BG)
        btn_frame.pack(anchor="w")
        tk.Button(btn_frame, text="Browse File…", command=self._pick_file,
                  bg=BORDER, fg=TEXT, relief="flat", font=FONT_B,
                  padx=14, pady=6, cursor="hand2").pack(side="left")
        tk.Button(btn_frame, text="Upload & Extract →", command=self._upload,
                  bg=EMBER, fg=BTN_FG, relief="flat", font=FONT_H3,
                  padx=14, pady=6, cursor="hand2").pack(side="left", padx=(10, 0))

        self.upload_status = tk.Label(p, text="", bg=BG, fg=GREEN, font=FONT_SM)
        self.upload_status.pack(anchor="w", pady=4)

        # Results area
        section_label(p, "Extracted CTC Breakdown")
        self.upload_result = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.upload_result.pack(fill="x")
        tk.Label(self.upload_result,
                 text="Upload a file above to see extracted salary components.",
                 bg=PANEL, fg=MUTED, font=FONT_SM).pack(anchor="w")

        self._file_path = None

    def _pick_file(self):
        path = filedialog.askopenfilename(
            filetypes=[("Salary Documents", "*.pdf *.jpg *.jpeg *.png"),
                       ("All Files", "*.*")])
        if path:
            self._file_path = path
            self.file_lbl.config(text=f"Selected: {path.split('/')[-1]}", fg=TEXT)

    def _upload(self):
        if not self._file_path:
            messagebox.showwarning("No file", "Please select a file first.")
            return
        self.upload_status.config(text="Uploading…", fg=GOLD)
        threading.Thread(target=self._upload_worker, daemon=True).start()

    def _upload_worker(self):
        try:
            data = upload_file(self._file_path)
            self.after(0, self._show_upload_result, data)
        except Exception as e:
            self.after(0, lambda: self.upload_status.config(
                text=f"Error: {e}", fg=EMBER))

    def _show_upload_result(self, data):
        self.upload_status.config(text=f"✓ Extracted from {data['fileName']}", fg=GREEN)
        ex = data["extracted"]

        for w in self.upload_result.winfo_children():
            w.destroy()

        fields = [
            ("Gross CTC (Annual)",      fmt_inr(ex["grossCTC"]),       GOLD),
            ("Net Take-Home (Monthly)", fmt_inr(ex["netTakeHome"]),    GREEN),
            ("Basic Salary",            fmt_inr(ex["basicSalary"]),    TEXT),
            ("HRA",                     fmt_inr(ex["hra"]),            TEXT),
            ("Special Allowance",       fmt_inr(ex["specialAllowance"]), TEXT),
            ("PF (Annual)",             fmt_inr(ex["pf"]),             TEXT),
            ("TDS Deducted (Annual)",   fmt_inr(ex["tdsDeducted"]),    EMBER),
            ("Bonus",                   fmt_inr(ex["bonus"]),          TEXT),
            ("Gratuity",                fmt_inr(ex["gratuity"]),       TEXT),
            ("Est. Monthly Surplus",    fmt_inr(ex["monthlySurplus"]), GREEN),
        ]
        for label, value, color in fields:
            result_row(self.upload_result, label, value, color)

        if ex.get("notes"):
            tk.Label(self.upload_result, text="\nNotes:", bg=PANEL,
                     fg=GOLD, font=FONT_H3).pack(anchor="w")
            for note in ex["notes"]:
                tk.Label(self.upload_result, text=f"  • {note}",
                         bg=PANEL, fg=MUTED, font=FONT_SM,
                         wraplength=700, justify="left").pack(anchor="w")

        # Pre-fill FIRE tab with extracted values
        self._ctc_data = ex

    # ── FIRE Tab ────────────────────────────
    def _build_fire_tab(self, p):
        section_label(p, "FIRE Planning Calculator")

        form = card(p, pady=12, padx=14)
        self.f_gross    = labeled_entry(form, "Gross CTC / Year (₹)",       "1200000")
        self.f_net      = labeled_entry(form, "Net Take-Home / Month (₹)",  "75000")
        self.f_expenses = labeled_entry(form, "Monthly Expenses (₹)",       "45000")
        self.f_savings  = labeled_entry(form, "Existing Corpus / Savings (₹)", "200000")
        self.f_cur_age  = labeled_entry(form, "Current Age",                "25")
        self.f_ret_age  = labeled_entry(form, "Target Retirement Age",      "45")

        tk.Label(form, text="Risk Level", bg=PANEL, fg=MUTED,
                 font=FONT_SM, anchor="w").pack(anchor="w", pady=(8, 2))
        self.f_risk = tk.StringVar(value="moderate")
        rf = tk.Frame(form, bg=PANEL)
        rf.pack(anchor="w")
        for val, label in [("conservative","Conservative"), ("moderate","Moderate"), ("aggressive","Aggressive")]:
            tk.Radiobutton(rf, text=label, variable=self.f_risk, value=val,
                           bg=PANEL, fg=TEXT, selectcolor=BG,
                           activebackground=PANEL, font=FONT_SM).pack(side="left", padx=6)

        btn(p, "Calculate FIRE Plan →", self._calc_fire)

        self.fire_status = tk.Label(p, text="", bg=BG, fg=GREEN, font=FONT_SM)
        self.fire_status.pack(anchor="w")

        section_label(p, "Your FIRE Summary")
        self.fire_summary = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.fire_summary.pack(fill="x")
        tk.Label(self.fire_summary, text="Fill in the form above and click Calculate.",
                 bg=PANEL, fg=MUTED, font=FONT_SM).pack(anchor="w")

        section_label(p, "Asset Allocation")
        self.fire_alloc = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.fire_alloc.pack(fill="x")

        section_label(p, "Year-by-Year Projection")
        self.fire_proj = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.fire_proj.pack(fill="x")

    def _calc_fire(self):
        try:
            payload = {
                "grossCTC"       : int(self.f_gross.get()),
                "netTakeHome"    : int(self.f_net.get()),
                "monthlyExpenses": int(self.f_expenses.get()),
                "currentSavings" : int(self.f_savings.get()),
                "currentAge"     : int(self.f_cur_age.get()),
                "targetAge"      : int(self.f_ret_age.get()),
                "riskLevel"      : self.f_risk.get(),
            }
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers in all fields.")
            return

        self.fire_status.config(text="Calculating…", fg=GOLD)
        threading.Thread(target=lambda: self._fire_worker(payload), daemon=True).start()

    def _fire_worker(self, payload):
        try:
            data = post("fire/calculate", payload)
            self.after(0, self._show_fire, data)
        except Exception as e:
            self.after(0, lambda: self.fire_status.config(text=f"Error: {e}", fg=EMBER))

    def _show_fire(self, data):
        self.fire_status.config(text="✓ FIRE plan ready", fg=GREEN)
        s = data["summary"]

        # Summary
        for w in self.fire_summary.winfo_children(): w.destroy()
        rows = [
            ("FIRE Number",              fmt_inr(s["fireNumber"]),        GOLD),
            ("Years to FIRE",            f"{s['yearsToFIRE']} years",    TEXT),
            ("Required Monthly SIP",     fmt_inr(s["requiredSIP"]),       EMBER),
            ("Monthly Surplus",          fmt_inr(s["monthlySurplus"]),    GREEN),
            ("Savings Rate",             f"{s['savingsRate']}%",          GREEN),
            ("Projected Annual Return",  f"{s['annualReturn']}%",         TEXT),
            ("Inflated Annual Expenses", fmt_inr(s["inflatedExpenses"]),  TEXT),
            ("Estimated Tax Saved",      fmt_inr(s["estimatedTaxSaved"]), GREEN),
        ]
        for label, value, color in rows:
            result_row(self.fire_summary, label, value, color)

        # Allocation
        for w in self.fire_alloc.winfo_children(): w.destroy()
        colors_map = {"equity": GREEN, "debt": GOLD, "hybrid": TEXT, "alt": EMBER}
        for item in data["allocation"]:
            f = tk.Frame(self.fire_alloc, bg=PANEL)
            f.pack(fill="x", pady=2)
            c = colors_map.get(item["type"], TEXT)
            tk.Label(f, text=f"{item['percent']:>3}%", bg=PANEL, fg=c,
                     font=("Courier", 10, "bold"), width=5).pack(side="left")
            # bar
            bar_w = max(4, item["percent"] * 4)
            tk.Frame(f, bg=c, width=bar_w, height=14).pack(side="left", padx=(4, 8))
            tk.Label(f, text=item["name"], bg=PANEL, fg=TEXT, font=FONT_SM).pack(side="left")

        # Projection table (first 10 years)
        for w in self.fire_proj.winfo_children(): w.destroy()
        hdr = tk.Frame(self.fire_proj, bg=BORDER)
        hdr.pack(fill="x")
        for col, w in [("Age", 6), ("Corpus", 16), ("Target", 16), ("Progress", 10)]:
            tk.Label(hdr, text=col, bg=BORDER, fg=GOLD, font=FONT_H3,
                     width=w, anchor="w").pack(side="left", padx=4, pady=4)

        for row in data["projection"][:15]:
            r = tk.Frame(self.fire_proj, bg=PANEL)
            r.pack(fill="x")
            pct = row["percent"]
            col = GREEN if pct >= 100 else GOLD if pct >= 50 else TEXT
            for val, w in [
                (str(row["year"]),             6),
                (fmt_inr(row["corpus"]),       16),
                (fmt_inr(row["target"]),       16),
                (f"{pct}%",                    10),
            ]:
                tk.Label(r, text=val, bg=PANEL, fg=col if val.endswith("%") else TEXT,
                         font=FONT_MO, width=w, anchor="w").pack(side="left", padx=4, pady=2)

    # ── Business Tab ────────────────────────
    def _build_business_tab(self, p):
        section_label(p, "Business Profiler")

        form = card(p, pady=12, padx=14)

        tk.Label(form, text="Business Type", bg=PANEL, fg=MUTED,
                 font=FONT_SM, anchor="w").pack(anchor="w", pady=(4, 4))
        self.b_type = tk.StringVar(value="b2b-software")
        bf = tk.Frame(form, bg=PANEL)
        bf.pack(anchor="w")
        for val, label in [
            ("b2b-software", "B2B Software"),
            ("b2c-software", "B2C Software"),
            ("b2b-product",  "B2B Product"),
            ("b2c-product",  "B2C Product"),
        ]:
            tk.Radiobutton(bf, text=label, variable=self.b_type, value=val,
                           bg=PANEL, fg=TEXT, selectcolor=BG,
                           activebackground=PANEL, font=FONT_SM).pack(side="left", padx=6)

        self.b_capital  = labeled_entry(form, "Startup Capital Available (₹)", "500000")
        self.b_hours    = labeled_entry(form, "Hours per Week (alongside job)",  "15")
        self.b_salary   = labeled_entry(form, "Monthly Net Salary (₹)",          "75000")
        self.b_savings  = labeled_entry(form, "Current Savings (₹)",             "300000")

        btn(p, "Generate Business Strategy →", self._calc_business)

        self.biz_status = tk.Label(p, text="", bg=BG, fg=GREEN, font=FONT_SM)
        self.biz_status.pack(anchor="w")

        section_label(p, "Business Summary")
        self.biz_summary = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.biz_summary.pack(fill="x")
        tk.Label(self.biz_summary, text="Fill in the form and click Generate.",
                 bg=PANEL, fg=MUTED, font=FONT_SM).pack(anchor="w")

        section_label(p, "Top States to Incorporate")
        self.biz_states = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.biz_states.pack(fill="x")

        section_label(p, "Legal Documents Required")
        self.biz_legal = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.biz_legal.pack(fill="x")

        section_label(p, "Dual Income Timeline (first 24 months)")
        self.biz_timeline = tk.Frame(p, bg=PANEL, pady=12, padx=14)
        self.biz_timeline.pack(fill="x")

    def _calc_business(self):
        try:
            payload = {
                "type"          : self.b_type.get(),
                "capital"       : int(self.b_capital.get()),
                "hoursPerWeek"  : int(self.b_hours.get()),
                "monthlySalary" : int(self.b_salary.get()),
                "currentSavings": int(self.b_savings.get()),
            }
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers.")
            return

        self.biz_status.config(text="Profiling…", fg=GOLD)
        threading.Thread(target=lambda: self._biz_worker(payload), daemon=True).start()

    def _biz_worker(self, payload):
        try:
            data = post("business/profile", payload)
            self.after(0, self._show_business, data)
        except Exception as e:
            self.after(0, lambda: self.biz_status.config(text=f"Error: {e}", fg=EMBER))

    def _show_business(self, data):
        self.biz_status.config(text="✓ Business strategy ready", fg=GREEN)
        s = data["summary"]

        # Summary
        for w in self.biz_summary.winfo_children(): w.destroy()
        rows = [
            ("Revenue Model",           s["revenueModel"],                    GOLD),
            ("Est. Monthly Burn Rate",  fmt_inr(s["monthlyBurn"]),            EMBER),
            ("Safety Runway",           f"{s['runwayMonths']} months",        TEXT),
            ("Break-Even Month",        f"Month {s['breakEvenMonth']}",       GREEN),
            ("Transition Point",        f"Month {s['transitionMonth']}",      GREEN),
            ("Safe Years Alongside Job",f"{s['safeYears']} years",            GOLD),
            ("GTM Strategy",            s["gtmStrategy"],                     TEXT),
            ("MVP Scope",               s["mvpScope"],                        TEXT),
        ]
        for label, value, color in rows:
            result_row(self.biz_summary, label, value, color)

        # States
        for w in self.biz_states.winfo_children(): w.destroy()
        for i, st in enumerate(data["states"], 1):
            f = card(self.biz_states, pady=6, padx=10)
            tk.Label(f, text=f"#{i}  {st['state']}", bg=PANEL, fg=GOLD,
                     font=FONT_H3).pack(anchor="w")
            tk.Label(f, text=st["reason"], bg=PANEL, fg=MUTED, font=FONT_SM,
                     wraplength=700, justify="left").pack(anchor="w")

        # Legal docs
        for w in self.biz_legal.winfo_children(): w.destroy()
        docs = data["legalDocs"]
        mid = len(docs) // 2
        cols = tk.Frame(self.biz_legal, bg=PANEL)
        cols.pack(fill="x")
        left  = tk.Frame(cols, bg=PANEL)
        right = tk.Frame(cols, bg=PANEL)
        left.pack(side="left", fill="x", expand=True)
        right.pack(side="left", fill="x", expand=True)
        for i, doc in enumerate(docs):
            parent = left if i < mid else right
            tk.Label(parent, text=f"  ✓  {doc}", bg=PANEL, fg=TEXT,
                     font=FONT_SM, anchor="w").pack(anchor="w", pady=1)

        # Timeline table
        for w in self.biz_timeline.winfo_children(): w.destroy()
        hdr = tk.Frame(self.biz_timeline, bg=BORDER)
        hdr.pack(fill="x")
        for col, w in [("Mo", 4), ("Job Income", 13), ("Biz Income", 13), ("Net Cashflow", 14), ("Status", 18)]:
            tk.Label(hdr, text=col, bg=BORDER, fg=GOLD, font=FONT_H3,
                     width=w, anchor="w").pack(side="left", padx=4, pady=4)

        status_colors = {
            "pre-breakeven"     : EMBER,
            "growing"           : GOLD,
            "ready-to-transition": GREEN,
        }
        for row in data["timeline"][:24]:
            r = tk.Frame(self.biz_timeline, bg=PANEL)
            r.pack(fill="x")
            sc = status_colors.get(row["status"], TEXT)
            cashflow_color = GREEN if row["netCashflow"] >= 0 else EMBER
            for val, wd, color in [
                (str(row["month"]),             4,  TEXT),
                (fmt_inr(row["jobIncome"]),    13,  TEXT),
                (fmt_inr(row["businessIncome"]),13, GOLD),
                (fmt_inr(row["netCashflow"]), 14,  cashflow_color),
                (row["status"].replace("-", " "), 18, sc),
            ]:
                tk.Label(r, text=val, bg=PANEL, fg=color,
                         font=FONT_MO, width=wd, anchor="w").pack(side="left", padx=4, pady=1)


# ──────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────
if __name__ == "__main__":
    app = RunwayIQ()
    app.mainloop()

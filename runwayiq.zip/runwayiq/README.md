# RunwayIQ

From Payslip to Financial Freedom.

---

## Project Structure

```
runwayiq/
├── backend/
│   ├── server.js                   ← Node.js Express entry point
│   ├── package.json
│   ├── routes/
│   │   ├── fire.js
│   │   ├── business.js
│   │   └── upload.js
│   └── controllers/
│       ├── fireController.js       ← FIRE calculation logic
│       ├── businessController.js   ← Business profiler logic
│       └── uploadController.js     ← CTC file handler
└── frontend/
    └── app.py                      ← Python Tkinter desktop app
```

---

## Setup

### 1. Backend (Node.js)

```bash
cd backend
npm install
node server.js
```

Backend runs at: http://localhost:3000

### 2. Frontend (Python)

```bash
cd frontend
pip install requests
python app.py
```

> Tkinter comes built-in with Python. No extra install needed.

---

## API Endpoints

| Method | Endpoint              | Description                  |
|--------|-----------------------|------------------------------|
| GET    | /api/health           | Backend health check         |
| POST   | /api/fire/calculate   | Run FIRE calculation         |
| POST   | /api/business/profile | Profile business type        |
| POST   | /api/upload/ctc       | Upload salary slip (PDF/IMG) |

---

## Notes

- The CTC upload currently uses a **mock parser**. Replace `parsePDFMock()` in `uploadController.js` with a real **Google Document AI** call for production.
- Not SEBI registered. For informational purposes only.

// ============================================
// RunwayIQ — controllers/uploadController.js
// PDF upload handler (mocked parser)
// Replace parsePDF() with Google Document AI
// or pdfparse in production
// ============================================

const path = require("path");
const fs   = require("fs");

/**
 * POST /api/upload/ctc
 * Accepts a PDF/image file via multipart form.
 * Returns extracted CTC fields.
 */
function uploadCTC(req, res) {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded." });
  }

  const filePath = req.file.path;
  const fileName = req.file.originalname;
  const fileSize = (req.file.size / 1024).toFixed(1) + " KB";

  // --- In production: send filePath to Google Document AI ---
  // For now, return a realistic mock extraction
  const extracted = parsePDFMock(fileName);

  // Clean up uploaded file
  fs.unlink(filePath, () => {});

  return res.json({
    fileName,
    fileSize,
    extracted,
    message: "CTC extracted successfully. Connect Google Document AI for real parsing.",
  });
}

/**
 * Mock CTC parser — replace with real Document AI call.
 * Simulates output for a ₹12 LPA CTC.
 */
function parsePDFMock(fileName) {
  return {
    grossCTC          : 1200000,
    netTakeHome       : 75000,
    basicSalary       : 500000,
    hra               : 200000,
    specialAllowance  : 180000,
    pf                : 72000,
    tdsDeducted       : 95000,
    bonus             : 100000,
    gratuity          : 28846,
    monthlySurplus    : 30000,   // estimated (take-home - avg expenses)
    notes: [
      "HRA exemption may apply if renting — consult CA.",
      "PF contribution eligible for 80C deduction.",
      "Ensure Form 16 matches TDS deducted.",
    ],
  };
}

module.exports = { uploadCTC };

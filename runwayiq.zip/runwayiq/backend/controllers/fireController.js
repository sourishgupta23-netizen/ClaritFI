// ============================================
// RunwayIQ — controllers/fireController.js
// FIRE planning calculation logic
// ============================================

/**
 * Calculate FIRE plan from salary and user inputs
 *
 * POST /api/fire/calculate
 * Body: {
 *   grossCTC        : number  (annual, in rupees)
 *   netTakeHome     : number  (monthly, in rupees)
 *   monthlyExpenses : number  (current monthly spend)
 *   currentAge      : number
 *   targetAge       : number  (age to retire)
 *   riskLevel       : string  "conservative" | "moderate" | "aggressive"
 *   currentSavings  : number  (existing corpus, optional)
 * }
 */
function calculateFIRE(req, res) {
  const {
    grossCTC,
    netTakeHome,
    monthlyExpenses,
    currentAge,
    targetAge,
    riskLevel       = "moderate",
    currentSavings  = 0,
  } = req.body;

  // --- Validate inputs ---
  if (!grossCTC || !netTakeHome || !monthlyExpenses || !currentAge || !targetAge) {
    return res.status(400).json({ error: "Missing required fields." });
  }

  if (targetAge <= currentAge) {
    return res.status(400).json({ error: "Target age must be greater than current age." });
  }

  // --- Constants ---
  const INFLATION_RATE    = 0.06;   // 6% Indian avg inflation
  const SAFE_WITHDRAWAL   = 0.04;   // 4% rule
  const YEARS_TO_RETIRE   = targetAge - currentAge;

  // Return rates by risk level
  const RETURN_RATES = {
    conservative : 0.09,   // FDs + debt MFs
    moderate     : 0.12,   // 60% equity / 40% debt
    aggressive   : 0.15,   // 90% equity index funds
  };

  const annualReturn = RETURN_RATES[riskLevel] || RETURN_RATES.moderate;

  // --- Core calculations ---
  const annualExpenses      = monthlyExpenses * 12;
  const monthlySurplus      = netTakeHome - monthlyExpenses;
  const savingsRate         = ((monthlySurplus / netTakeHome) * 100).toFixed(1);

  // Inflate expenses to retirement year
  const inflatedExpenses    = annualExpenses * Math.pow(1 + INFLATION_RATE, YEARS_TO_RETIRE);
  const fireNumber          = inflatedExpenses / SAFE_WITHDRAWAL;

  // Future value of existing savings
  const fvCurrentSavings    = currentSavings * Math.pow(1 + annualReturn, YEARS_TO_RETIRE);

  // Required corpus from SIPs
  const requiredFromSIP     = fireNumber - fvCurrentSavings;

  // Required monthly SIP (PMT formula)
  const monthlyRate         = annualReturn / 12;
  const months              = YEARS_TO_RETIRE * 12;
  const requiredSIP         = requiredFromSIP > 0
    ? (requiredFromSIP * monthlyRate) / (Math.pow(1 + monthlyRate, months) - 1)
    : 0;

  // Corpus if investing full surplus
  const surplusCorpus       = monthlySurplus > 0
    ? monthlySurplus * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate)
    : 0;

  // Tax saving opportunities (80C, NPS, 80D)
  const maxSection80C       = 150000;
  const maxNPS              = 50000;
  const maxSection80D       = 25000;
  const totalTaxSaving      = maxSection80C + maxNPS + maxSection80D;
  const taxSlab             = grossCTC > 1500000 ? 0.30 : grossCTC > 1000000 ? 0.20 : 0.10;
  const estimatedTaxSaved   = totalTaxSaving * taxSlab;

  // Year-by-year projection
  const projection = [];
  let corpus = currentSavings;
  const monthlySIP = Math.max(requiredSIP, 0);

  for (let year = 1; year <= YEARS_TO_RETIRE; year++) {
    corpus = (corpus + monthlySIP * 12) * (1 + annualReturn);
    projection.push({
      year    : currentAge + year,
      corpus  : Math.round(corpus),
      target  : Math.round(fireNumber),
      percent : Math.min(100, Math.round((corpus / fireNumber) * 100)),
    });
  }

  // Asset allocation recommendation
  const allocation = getAllocation(riskLevel);

  return res.json({
    summary: {
      fireNumber       : Math.round(fireNumber),
      yearsToFIRE      : YEARS_TO_RETIRE,
      monthlySurplus   : Math.round(monthlySurplus),
      savingsRate      : parseFloat(savingsRate),
      requiredSIP      : Math.round(requiredSIP),
      surplusCorpus    : Math.round(surplusCorpus),
      inflatedExpenses : Math.round(inflatedExpenses),
      annualReturn     : (annualReturn * 100).toFixed(1),
      estimatedTaxSaved: Math.round(estimatedTaxSaved),
    },
    allocation,
    projection,
  });
}

function getAllocation(riskLevel) {
  const allocations = {
    conservative: [
      { name: "PPF / FD",          percent: 30, type: "debt"   },
      { name: "Debt Mutual Funds",  percent: 25, type: "debt"   },
      { name: "NPS (Tier 1)",       percent: 20, type: "hybrid" },
      { name: "Equity Index Funds", percent: 20, type: "equity" },
      { name: "Gold / REITs",       percent:  5, type: "alt"    },
    ],
    moderate: [
      { name: "Equity Index Funds", percent: 50, type: "equity" },
      { name: "ELSS (80C benefit)", percent: 15, type: "equity" },
      { name: "NPS (Tier 1)",       percent: 15, type: "hybrid" },
      { name: "Debt Mutual Funds",  percent: 12, type: "debt"   },
      { name: "Gold / REITs",       percent:  8, type: "alt"    },
    ],
    aggressive: [
      { name: "Equity Index Funds", percent: 60, type: "equity" },
      { name: "Small/Mid Cap MFs",  percent: 20, type: "equity" },
      { name: "ELSS (80C benefit)", percent: 10, type: "equity" },
      { name: "NPS (Tier 1)",       percent:  5, type: "hybrid" },
      { name: "Gold / REITs",       percent:  5, type: "alt"    },
    ],
  };
  return allocations[riskLevel] || allocations.moderate;
}

module.exports = { calculateFIRE };

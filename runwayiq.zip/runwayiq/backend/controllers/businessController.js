// ============================================
// RunwayIQ — controllers/businessController.js
// Business profiling + runway calculation
// ============================================

/**
 * POST /api/business/profile
 * Body: {
 *   type        : "b2b-software" | "b2c-software" | "b2b-product" | "b2c-product"
 *   capital     : number   (startup capital available in rupees)
 *   hoursPerWeek: number   (hours spare alongside job)
 *   monthlySalary: number  (net take-home)
 *   currentSavings: number
 *   industry    : string   (optional)
 * }
 */
function profileBusiness(req, res) {
  const {
    type,
    capital        = 0,
    hoursPerWeek   = 10,
    monthlySalary  = 0,
    currentSavings = 0,
    industry       = "general",
  } = req.body;

  if (!type) {
    return res.status(400).json({ error: "Business type is required." });
  }

  const profile    = BUSINESS_PROFILES[type];
  if (!profile) {
    return res.status(400).json({ error: "Invalid business type." });
  }

  // --- Monthly burn rate estimate ---
  const monthlyBurn     = profile.burnRate(capital);

  // --- Safety runway (months savings can sustain) ---
  const safetyBuffer    = currentSavings * 0.5;   // only use 50% of savings
  const runwayMonths    = monthlyBurn > 0 ? Math.floor(safetyBuffer / monthlyBurn) : 999;

  // --- Break-even estimate ---
  const breakEvenMonth  = profile.breakEvenMonths;

  // --- Full transition point ---
  // Month when business revenue likely = 80% of salary
  const transitionMonth = profile.transitionMonths;

  // --- Safe years alongside job ---
  const safeYears       = (Math.min(runwayMonths, transitionMonth) / 12).toFixed(1);

  // --- Top state recommendations ---
  const states          = getTopStates(type, industry);

  // --- Legal structure recommendation ---
  const legalDocs       = getLegalDocs(type, capital);

  // --- Revenue model ---
  const revenueModel    = profile.revenueModel;

  // --- Month-by-month dual income timeline ---
  const timeline        = buildTimeline(monthlySalary, profile, transitionMonth);

  return res.json({
    businessType  : type,
    summary: {
      monthlyBurn      : Math.round(monthlyBurn),
      runwayMonths,
      breakEvenMonth,
      transitionMonth,
      safeYears        : parseFloat(safeYears),
      revenueModel,
      mvpScope         : profile.mvpScope,
      gtmStrategy      : profile.gtmStrategy,
    },
    states,
    legalDocs,
    timeline,
  });
}

// --- Business profile definitions ---
const BUSINESS_PROFILES = {
  "b2b-software": {
    burnRate        : (capital) => Math.max(30000, capital * 0.08),
    breakEvenMonths : 18,
    transitionMonth : 30,
    revenueModel    : "SaaS subscription / annual contracts",
    mvpScope        : "Core feature set for 1 customer segment, basic dashboard, onboarding flow",
    gtmStrategy     : "LinkedIn outbound, founder-led sales, free trial → paid conversion",
  },
  "b2c-software": {
    burnRate        : (capital) => Math.max(20000, capital * 0.06),
    breakEvenMonths : 12,
    transitionMonth : 24,
    revenueModel    : "Freemium + premium tiers / in-app purchases",
    mvpScope        : "Single core loop, frictionless signup, one viral feature",
    gtmStrategy     : "App Store / Play Store SEO, influencer seeding, referral loops",
  },
  "b2b-product": {
    burnRate        : (capital) => Math.max(80000, capital * 0.12),
    breakEvenMonths : 24,
    transitionMonth : 42,
    revenueModel    : "Purchase orders / long-term supply contracts",
    mvpScope        : "Working prototype, 2–3 pilot customers, compliance certifications",
    gtmStrategy     : "Trade shows, procurement portals, distributor partnerships",
  },
  "b2c-product": {
    burnRate        : (capital) => Math.max(60000, capital * 0.10),
    breakEvenMonths : 18,
    transitionMonth : 36,
    revenueModel    : "D2C sales + marketplace (Amazon, Flipkart) + retail distribution",
    mvpScope        : "Single SKU, DTC Shopify store, 500 units pilot batch",
    gtmStrategy     : "Instagram/YouTube organic, micro-influencers, Amazon launch",
  },
};

// --- State recommender ---
function getTopStates(type, industry) {
  const stateScores = {
    "b2b-software" : [
      { state: "Karnataka",   reason: "Largest IT talent pool. Bangalore startup ecosystem. STPI benefits." },
      { state: "Telangana",   reason: "T-Hub support. Lower real estate costs than Bangalore. Good infra." },
      { state: "Maharashtra", reason: "Strong VC presence in Mumbai/Pune. Large enterprise customer base." },
    ],
    "b2c-software" : [
      { state: "Karnataka",   reason: "Young tech-savvy population. Strong angel investor network." },
      { state: "Delhi NCR",   reason: "Massive consumer market. Gurugram startup cluster." },
      { state: "Maharashtra", reason: "Mumbai fintech + consumer startup hub." },
    ],
    "b2b-product" : [
      { state: "Gujarat",     reason: "Strong manufacturing base. GIDC industrial zones. Port access." },
      { state: "Maharashtra", reason: "MIDC zones. Pune auto + engineering cluster." },
      { state: "Tamil Nadu",  reason: "Chennai manufacturing corridor. Auto + electronics SEZs." },
    ],
    "b2c-product" : [
      { state: "Delhi NCR",   reason: "Largest D2C consumer market. Logistics hub. Fashion + FMCG cluster." },
      { state: "Maharashtra", reason: "Mumbai brand HQ. Strong retail + logistics network." },
      { state: "Karnataka",   reason: "Bangalore D2C ecosystem. Good warehousing options." },
    ],
  };
  return stateScores[type] || stateScores["b2b-software"];
}

// --- Legal docs recommender ---
function getLegalDocs(type, capital) {
  const base = [
    "Certificate of Incorporation (MCA filing)",
    "Memorandum of Association (MOA)",
    "Articles of Association (AOA)",
    "Founder Agreement",
    "IP Assignment Agreement",
    "Non-Disclosure Agreement (NDA)",
    "GST Registration",
  ];

  if (capital > 2000000) {
    base.push("Shareholders Agreement");
    base.push("ESOP Policy");
  }

  if (type.includes("software")) {
    base.push("Terms of Service");
    base.push("Privacy Policy");
    base.push("Software License Agreement");
  }

  if (type.includes("product")) {
    base.push("Manufacturing Agreement / Contract");
    base.push("Vendor / Supplier Agreement");
  }

  if (type.startsWith("b2b")) {
    base.push("Master Service Agreement (MSA)");
    base.push("Statement of Work (SOW) Template");
  }

  return base;
}

// --- Dual income timeline builder ---
function buildTimeline(monthlySalary, profile, totalMonths) {
  const timeline = [];
  const cap      = Math.min(totalMonths + 6, 48);

  for (let month = 1; month <= cap; month++) {
    // Business revenue grows from 0 → 100% of salary over transitionMonth
    const progress       = Math.min(1, month / profile.transitionMonth);
    const businessIncome = Math.round(monthlySalary * progress * 0.85);
    const jobIncome      = monthlySalary;
    const totalIncome    = jobIncome + businessIncome;
    const burn           = Math.round(profile.burnRate(0));
    const netCashflow    = totalIncome - burn;

    timeline.push({
      month,
      jobIncome,
      businessIncome,
      totalIncome,
      burn,
      netCashflow,
      status: month < profile.breakEvenMonths
        ? "pre-breakeven"
        : month < profile.transitionMonth
        ? "growing"
        : "ready-to-transition",
    });
  }
  return timeline;
}

module.exports = { profileBusiness };

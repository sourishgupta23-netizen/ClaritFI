// routes/business.js
const express = require("express");
const router  = express.Router();
const { profileBusiness } = require("../controllers/businessController");

router.post("/profile", profileBusiness);

module.exports = router;

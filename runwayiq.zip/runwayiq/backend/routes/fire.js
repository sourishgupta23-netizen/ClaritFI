// routes/fire.js
const express = require("express");
const router  = express.Router();
const { calculateFIRE } = require("../controllers/fireController");

router.post("/calculate", calculateFIRE);

module.exports = router;

// routes/upload.js
const express = require("express");
const multer  = require("multer");
const router  = express.Router();
const { uploadCTC } = require("../controllers/uploadController");

const storage = multer.diskStorage({
  destination : (req, file, cb) => cb(null, "/tmp"),
  filename    : (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});

const upload = multer({
  storage,
  limits    : { fileSize: 10 * 1024 * 1024 },   // 10 MB
  fileFilter: (req, file, cb) => {
    const allowed = ["application/pdf", "image/jpeg", "image/png"];
    allowed.includes(file.mimetype) ? cb(null, true) : cb(new Error("Only PDF/JPG/PNG allowed"));
  },
});

router.post("/ctc", upload.single("file"), uploadCTC);

module.exports = router;

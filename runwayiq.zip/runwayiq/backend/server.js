// ============================================
// RunwayIQ — server.js
// Node.js + Express backend
// Run: node server.js
// ============================================

const express = require("express");
const cors    = require("cors");

const fireRoutes     = require("./routes/fire");
const businessRoutes = require("./routes/business");
const uploadRoutes   = require("./routes/upload");

const app  = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Routes
app.use("/api/fire",     fireRoutes);
app.use("/api/business", businessRoutes);
app.use("/api/upload",   uploadRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "RunwayIQ backend running" });
});

app.listen(PORT, () => {
  console.log(`RunwayIQ backend running at http://localhost:${PORT}`);
});
